export const environment = {
  production: true,
  BaseUrl: 'http://localhost:3000/',
  NewsApi: {
    Url: 'https://newsapi.org/v2/',
    apiKey: 'e7a4c5bc722148b5a0a58dc50475d19b'
  },
};
