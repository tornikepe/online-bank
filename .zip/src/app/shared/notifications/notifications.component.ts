import { NotificationsService } from './../notifications.service';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent implements OnInit{

  constructor(notificationsService: NotificationsService) { }

  // isDisplay:boolean =true;

  ngOnInit(){

    

    setTimeout(()=>{
      this.isDisplay=false;
    }, 3000);

  }

  @Input() text!: string;

  @Input() notifClass!: string;

  @Input() set bat(par:any){
    this.isDisplay=par;

    setTimeout(()=>{
      this.isDisplay=false;
    }, 3000);
  };
isDisplay=false;



  toggleDisplay(){
    this.isDisplay=!this.isDisplay;
  }

  show(){
    this.isDisplay=true;
  }
  
}


