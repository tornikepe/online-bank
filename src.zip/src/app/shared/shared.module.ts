import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ToggleComponent } from './toggle/toggle.component';
import { TabsGroupComponent } from './tabs-group/tabs-group.component';
import { SingleTab } from './tabs-group/tab.component';
import { InputComponent } from './input/input.component';
import { ProgressbarComponent } from "./components/progressbar/progressbar.component";
import { NotificationsComponent } from "./notifications/notifications.component";


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ToggleComponent,
    TabsGroupComponent,
    SingleTab,
    InputComponent,
    ProgressbarComponent,
    NotificationsComponent
  ],
  exports: [
    TabsGroupComponent,
    SingleTab,
    ToggleComponent,
    InputComponent,
    ProgressbarComponent,
    NotificationsComponent
  ]
})

export class SharedModule {}